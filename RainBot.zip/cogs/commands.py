from main import plogging, check_user_cooldown, play_audio, bot_sound
import disnake
import asyncio
import datetime
from disnake.ext import commands

global last_use_time
last_use_time = {}
global moving
moving = {}
global move
move = {}
global test
test = {}
ALLOWED_USER_ID = 604942094741798912

class Commands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    @commands.slash_command(name="reload", description="Reload all cogs.")
    async def reload_all_cogs(self, ctx: commands.Context):
        # Проверяем, что команду вызвал только вы
        embed = disnake.Embed(
            description=f"You are not authorized to use this command.",
            colour=0xF0C43F,
        )
        embed.set_footer(
            text="© RainBot",
        ) 
        
        if ctx.author.id != ALLOWED_USER_ID:
            await ctx.followup.send(embed=embed)
            return

        try:
            # Перезагружаем все коги
            for cog in ctx.bot.extensions:
                ctx.bot.reload_extension(cog)
            await ctx.followup.send("All cogs reloaded successfully.")
        except Exception as e:
            await ctx.followup.send(f"Failed to reload all cogs: {e}")
            
    @commands.slash_command(name="moving", description="Move a user tuda syuda.")
    async def moving(self, ctx: disnake.ApplicationCommandInteraction, member: disnake.Member):
        try:
            await ctx.response.defer(ephemeral=True)
            
            await plogging(f"Command   'moving'   was used by   {ctx.author.display_name}\nTry to moving {member.display_name}")
            # Проверяем, присоединен ли участник к голосовому каналу
            if ctx.author.voice is None or ctx.author.voice.channel is None:
                await plogging(f"User {ctx.author.display_name} is not in a voice channel.")
                embed = disnake.Embed(
                    description=f"You are not in a voice channel!",
                    colour=0xF0C43F,
                )
                embed.set_footer(
                    text="© RainBot",
                ) 
                await ctx.followup.send(embed=embed)
                return
            if member.voice is None or member.voice.channel is None:
                embed = disnake.Embed(
                    description=f"{member.mention} is not connected to a voice channel.",
                    colour=0xF0C43F,
                )
                embed.set_footer(
                    text="© RainBot",
                ) 
                await ctx.followup.send(embed=embed)
                return
            
            user_id = ctx.author.id
            if not hasattr(moving, 'last_use_time'):
                moving.last_use_time = {}  # Создаем словарь для хранения времени последнего использования команды
            
            
            user_id = ctx.author.id
            if user_id in moving.last_use_time:
                last_use_time = moving.last_use_time[user_id]
                cooldown = await check_user_cooldown(member_id=user_id, command_name="moving", last_command_use=last_use_time)
                if cooldown != 0:
                    embed = disnake.Embed(
                        description=f"You have {cooldown} sec. cooldown left for this command.",
                        colour=0xF0C43F,
                    )
                    embed.set_footer(
                        text="© RainBot",
                    ) 
                    await ctx.followup.send(embed=embed)
                    await plogging(f"User have a {cooldown} sec. cooldown.")
                    return

            # Устанавливаем текущее время как время последнего использования команды для данного пользователя
            moving.last_use_time[user_id] = datetime.datetime.now()

            # Получаем текущий канал участника
            current_channel = member.voice.channel
            channel1 = ctx.guild.get_channel(1212058316138872902)
            channel2 = ctx.guild.get_channel(1212058374796218459)
            for i in range(1, 2, 1):
                # Перемещаем участника в указанный канал
                await member.move_to(channel1)
                # Перемещаем участника обратно в исходный канал
                await member.move_to(channel2)
            await member.move_to(current_channel)
            embed = disnake.Embed(
                description="Successfully.",
                colour=0xF0C43F,
            )
            embed.set_footer(
                text="© RainBot",
            ) 
            await ctx.followup.send(embed=embed)
        except disnake.errors.Forbidden:
            await ctx.followup.send("I don't have permissions to move users.")
        except disnake.errors.HTTPException:
            await ctx.followup.send("Failed to move the user.")
            
    @commands.slash_command(name="move", description="Move a user to a specified voice channel.")
    async def move(self, ctx: disnake.ApplicationCommandInteraction, member: disnake.Member, channel: disnake.VoiceChannel):
        try:
            await ctx.response.defer(ephemeral=True)
            
            await plogging(f"Command 'move' was used by {ctx.author.display_name}\nTry to move {member.display_name} to {channel.name}")

            # Проверяем, подключен ли участник к каналу
            if ctx.author.voice is None or ctx.author.voice.channel is None:
                embed = disnake.Embed(
                    description="You are not in a voice channel!",
                    colour=0xF0C43F,
                )
                embed.set_footer(
                    text="© RainBot",
                )
                await plogging(f"User {ctx.author.display_name} is not in a voice channel.")
                await ctx.followup.send(embed=embed)
                return
            if member.voice is None or member.voice.channel is None:
                embed = disnake.Embed(
                    description=f"{member.mention} is not connected to a voice channel.",
                    colour=0xF0C43F,
                )
                embed.set_footer(
                    text="© RainBot",
                )
                await ctx.followup.send(embed=embed)
                return
            user_id = ctx.author.id
            if not hasattr(move, 'last_use_time'):
                move.last_use_time = {}  # Создаем словарь для хранения времени последнего использования команды
            
            user_id = ctx.author.id
            if user_id in move.last_use_time:
                last_use_time = move.last_use_time[user_id]
                cooldown = await check_user_cooldown(member_id=user_id, command_name="move", last_command_use=last_use_time)
                if cooldown != 0:
                    embed = disnake.Embed(
                    description=f"You have {cooldown} sec. cooldown left for this command.",
                    colour=0xF0C43F,
                    )
                    embed.set_footer(
                        text="© RainBot",
                    )
                    await ctx.followup.send(embed=embed)
                    await plogging(f"User have a {cooldown} sec. cooldown.")
                    return

            # Устанавливаем текущее время как время последнего использования команды для данного пользователя
            move.last_use_time[user_id] = datetime.datetime.now()
            
            await member.move_to(channel)
            embed = disnake.Embed(
                description=f"{member.mention} successfully moved to {channel.mention}.",
                colour=0xF0C43F,
            )
            embed.set_footer(
                text="© RainBot",
            )
            await ctx.followup.send(embed=embed)        
        except disnake.errors.Forbidden:
            await ctx.followup.send("I don't have permissions to move users.")
        except disnake.errors.HTTPException:
            await ctx.followup.send("Failed to move the user.")
        except Exception as e:
            await ctx.followup.send(f"An error occurred: {e}", ephemeral=True)

        
        
        
        
        
        
        
    @commands.slash_command(name="test", description="test command.")
    async def test(self, ctx):

        await plogging(f"Command 'test' was used by {ctx.author.display_name}")

        await ctx.response.defer(ephemeral=True)
        user_id = ctx.author.id
        if not hasattr(test, 'last_use_time'):
            test.last_use_time = {}  # Создаем словарь для хранения времени последнего использования команды
        
        user_id = ctx.author.id
        if user_id in test.last_use_time:
            last_use_time = test.last_use_time[user_id]
            cooldown = await check_user_cooldown(member_id=user_id, command_name="test", last_command_use=last_use_time)
            if cooldown != 0:
                await ctx.followup.send(f"You have {cooldown} sec. cooldown left for this command.")
                await plogging(f"User have a {cooldown} sec. cooldown.")
                return   
            
    # Устанавливаем текущее время как время последнего использования команды для данного пользователя
        test.last_use_time[user_id] = datetime.datetime.now()
        embed = disnake.Embed(
            description="Test successfully.",
            colour=0xF0C43F,
        )
        embed.set_footer(
        text="© RainBot",
        )
        await ctx.followup.send(embed=embed)  
def setup(bot):
    bot.add_cog(Commands(bot))