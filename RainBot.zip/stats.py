import disnake
from disnake.ext import tasks
import json
import os
from datetime import datetime, timedelta, timezone

# Директория для хранения файлов статистики
STATS_DIR = "stats"

if not os.path.exists(STATS_DIR):
    os.makedirs(STATS_DIR)

def load_user_stats(user_id):
    """Загрузка статистики пользователя из файла."""
    stats_path = os.path.join(STATS_DIR, f"{user_id}.json")
    if os.path.exists(stats_path):
        with open(stats_path, "r") as f:
            stats = json.load(f)
            # Добавляем отсутствующие поля со значениями по умолчанию
            for key in ["voice_time", "mute_time", "deaf_time", "alone_time", "afk_time"]:
                if key not in stats:
                    stats[key] = 0
            return stats
    return {
        "name": "",
        "voice_time": 0,
        "mute_time": 0,
        "deaf_time": 0,
        "alone_time": 0,
        "afk_time": 0
    }

def save_user_stats(user_id, user_name, stats):
    """Сохранение статистики пользователя в файл."""
    stats_path = os.path.join(STATS_DIR, f"{user_id}.json")
    stats["name"] = user_name  # Добавляем имя пользователя
    with open(stats_path, "w") as f:
        json.dump(stats, f)

async def update_stats(user, stat_key, delta_time):
    """Обновление статистики пользователя."""
    stats = load_user_stats(user.id)
    stats[stat_key] += delta_time.total_seconds()
    save_user_stats(user.id, user.name, stats)  # Передаем имя пользователя

async def update_all_users_stats(guild):
    """Обновление статистики для всех пользователей на сервере."""
    now = datetime.now(timezone.utc)
    for member in guild.members:
        if member.voice:
            if member.voice.self_mute:
                await update_stats(member, "mute_time", timedelta(seconds=3))
            if member.voice.self_deaf:
                await update_stats(member, "deaf_time", timedelta(seconds=3))
            if member.voice.channel == member.guild.afk_channel:
                await update_stats(member, "afk_time", timedelta(seconds=3))
            if len(member.voice.channel.members) == 1:
                await update_stats(member, "alone_time", timedelta(seconds=3))
            await update_stats(member, "voice_time", timedelta(seconds=3))

@tasks.loop(seconds=3)
async def periodic_stats_update(bot):
    """Фоновая задача для периодического обновления статистики."""
    for guild in bot.guilds:
        await update_all_users_stats(guild)

async def on_voice_state_update(member, before, after):
    """Обработка изменений состояния голосового канала."""
    pass

async def on_presence_update(before, after):
    """Обработка изменений статуса пользователя."""
    pass

def get_user_statistics(user_id):
    """Получение статистики пользователя по ID."""
    stats = load_user_stats(user_id)
    return stats