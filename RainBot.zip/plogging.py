import os
import gzip
import datetime

logs_dir = "./logs"
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

time_now_logs = datetime.datetime.now()
formatted_time_logs = time_now_logs.strftime("%d-%m-%Y_%H-%M-%S")
log_filename = f"log_{formatted_time_logs}.txt"
log_filepath = os.path.join(logs_dir, log_filename)

# Проверяем, существуют ли уже файлы журналов в папке
log_files = [file for file in os.listdir(logs_dir) if file.endswith(".txt")]

def archive_logs():
    if log_files:
        # Если есть файлы журналов, архивируем их
        for file in log_files:
            # Создаем архивный файл
            archive_filename = f"{file[:-4]}_archive.gz"  # Имя архива с добавлением _archive
            archive_filepath = os.path.join(logs_dir, archive_filename)
            
            with open(os.path.join(logs_dir, file), 'rb') as f_in, gzip.open(archive_filepath, 'wb') as f_out:
                f_out.writelines(f_in)
            
            # Удаляем оригинальный файл журнала
            os.remove(os.path.join(logs_dir, file))
            
            print(f"Файл журнала {file} успешно архивирован в {archive_filepath}")

def create_log_file():
    try:
        with open(log_filepath, 'w') as f:
            pass
        print(f"Файл журнала успешно создан: {log_filepath}")
    except Exception as e:
        print(f"Ошибка при создании файла журнала: {e}")

# Выполняем архивирование и создаем новый файл журнала при импорте модуля
archive_logs()
create_log_file()

async def plogging(a):
    time_now = datetime.datetime.now()  # Вызов метода now() от класса datetime.datetime
    formatted_time = time_now.strftime("%H:%M:%S")
    print(f"[{formatted_time}] {a}")
    with open(log_filepath, "a", encoding="utf-8") as log_file:  # Указываем кодировку UTF-8
        log_file.write(f"[{formatted_time}] {a} \n")